import React from 'react'
import './Signup.css'
const AfterOtp = () => {
    return (
        <div>
        
         



            
        </div>
    )
}

export default AfterOtp
