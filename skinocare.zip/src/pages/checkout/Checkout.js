import React from 'react'
import Navbar2 from '../../componets/navbar2/Navbar2'
import Checkoutpage from '../../componets/checkoutpage/Checkoutpage'
import Privcy from '../../componets/privecy/Privcy'

const Checkout = () => {
  return (
    <>

    
    <Checkoutpage/>
    <Privcy/>
      
    </>
  )
}

export default Checkout
