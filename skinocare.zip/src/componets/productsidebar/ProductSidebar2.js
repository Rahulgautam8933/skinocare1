import React from 'react'

const ProductSidebar2 = ({close}) => {
  return (
    <>

    <div   className="productsidebarmaincontainer">
    <div className="producsidbarboxs">
        <div className="productsidbarbox">
        <div className="closebutton">
        <h2>How to use ?</h2>
        <p onClick={close} className='closebutton' ><i class="zmdi zmdi-close"></i></p>
        </div>
       <p><strong>1. </strong> Lorem  ipsum Lorem ipsum dolor sit amet consectetur adipisicing elit. dolor sit amet, consectetur adipisicing elit. Quasi, unde.</p>
       <p><strong>2. </strong> Lorem ipsum dolor sit amet, consectetur Lorem, ipsum dolor. adipisicing elit. Quasi, unde.</p>
       <p><strong>3. </strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, unde.</p>
       <p><strong>4. </strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, unde. Lorem, ipsum dolor sit amet consectetur adipisicing elit. Eligendi amet assumenda aut architecto dolorem earum quidem cupiditate aperiam illum inventore, magni expedita omnis, fuga, temporibus voluptatum iusto aspernatur modi eaque.</p>
       <p><strong>5. </strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, unde.</p>
       <p><strong>6. </strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, unde.</p>
       <p><strong>7. </strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, unde. Lorem ipsum dolor sit, amet consectetur adipisicing elit. Quam, quas.</p>
       <p><strong>8. </strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, unde.</p>
       <p><strong>9. </strong> Lorem ipsum dolor sit amet, consectetur adipisicing elit. Quasi, unde. Lorem ipsum dolor sit amet.</p>



        </div>
    </div>

</div>

      
    </>
  )
}

export default ProductSidebar2
