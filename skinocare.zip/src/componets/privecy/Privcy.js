import React from 'react'

const Privcy = () => {
    return (
        <>
            <div className="privcycontainer">

                <div className="privcyboxs">
                    <ul>
                        <li>Shipping policy </li>
                        <li>Refund policy </li>
                        <li>Privacy policy </li>
                        <li>Privacy policy </li>
                    </ul>

                </div>

            </div>

        </>
    )
}

export default Privcy
