import React from 'react'
import './PrivcyPolicy.css'
import SkinAndCareHeading from '../skinAndCareHeading/SkinAndCareHeading'
const TermsofService = () => {
    const h2 = `Terms of Service`
    return (
        <>

            <div className="privcyPolicyMainContainer">
                <div className="privcyPolicycontainer">
                    <SkinAndCareHeading h2={h2} />
                    <div className="privcypolicycontent">
                        <p>Lorem ipsum dolor, sit amet consectetur adipisicing elit. Ipsa ad vel magni.</p>
                        <p>Lorem ipsum  Lorem ipsum dolor, sit amet consectetur adipisicing elit. Et, molestias esse! Nemo vel eius quidem, non illo incidunt neque ratione iure quos sed esse tempora illum officiis ab, soluta, iusto blanditiis qui animi? Pariatur animi tempora necessitatibus dolore optio minima quaerat quidem eligendi vero nulla qui, a provident tempore blanditiis repellat dignissimos dolorem fugiat ipsam! Laboriosam, repellat eum provident ad ab soluta fugit in quia error odit reprehenderit quas quidem possimus adipisci necessitatibus ratione iure ullam quo natus ipsam, tempora accusantium? Dicta quod beatae odit labore, sed possimus voluptatem, eveniet sit incidunt nisi expedita! Tempore doloremque beatae quasi tempora expedita! dolor, sit amet consectetur adipisicing elit. Ipsa ad vel magni.</p>

                    </div>
                </div>
            </div>
            
        </>
    )
}

export default TermsofService
