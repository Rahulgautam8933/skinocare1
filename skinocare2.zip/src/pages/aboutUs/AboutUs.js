import React from 'react'
import SkinAndCareHeading from '../../componets/skinAndCareHeading/SkinAndCareHeading'
import './AboutUs.css'
import improveskills from '../../img/improveskills.png'
const AboutUs = () => {
    const h2 = `"Using straightforward technology to tackle the intricacies of skin and hair."`
    const p = `"In 2017, accessing a dermatologist's expertise for everyday skin and hair care was a challenge we recognized. This led us to harness the power of AI to provide continuous dermatologist care through the Cureskin app, making expert care accessible."`
    return (
        <>
            <div className="aboutUsContainer">

                <div className="AboutUsHeading">
                    <SkinAndCareHeading h2={h2} p={p} />
                </div>

                <div className="improvingskils">

                    <div className="improvingskillbox">

                        <div className="improvingskillboxContainer">

                            <div className="improvingskillboxheding">
                                <h2>"Improving skin and hair health on a daily basis."</h2>
                                <p>"We recognize the influence of incorrect products, mental well-being, nutrition, and environmental elements on your skin and hair. That's why we meticulously analyze your photos, ask pertinent questions, and take into account these factors to curate a personalized kit aligned with your skin and hair objectives."</p>
                            </div>
                            <h6>We simplify skin & hair care with 3 essential personalizations</h6>

                            <div className="improveskillpoint">
                                <p>A personal dermatologist assigned to you</p>
                                <p>A personal regimen based on your skin & hair needs</p>
                                <p>A personal tracking system to monitor your skin & hair progress</p>

                            </div>
                        </div>


                    </div>

                    <div className="improvingskillbox">

                        <div className="improvingskillimgbox">

                            <img src={improveskills} alt="" />
                        </div>



                    </div>

                </div>
            </div>
        </>
    )
}

export default AboutUs
